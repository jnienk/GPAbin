utils::globalVariables(c(
  "tick", "var", "var.name", "slope", "hadj", "vadj", "V1", "V2", "Group",".data"
))
